
def sectionA():
    print("Food section")

def sectionB():
    print("Home needs")

if __name__== "__main__":
    print("sales file")
    sectionA()